const discord_js = require('discord.js')
const dotenv = require('dotenv')
dotenv.config()

const client = new discord_js.Client({
    intents: [
        discord_js.GatewayIntentBits.Guilds,
        discord_js.GatewayIntentBits.GuildMessages,
        discord_js.GatewayIntentBits.MessageContent,
        discord_js.GatewayIntentBits.GuildPresences
    ]
})

client.on('ready', async () => {
    await client.user.setPresence({ activities: [{ name: 'TYPE HERE CUSTOM STATUS' }], status: 'online' });

    console.log('The bot is ready')
});

client.on('messageCreate', async message => {
    if (message.content === '!Ping') {
        console.log("Ping Command Used.");
        message.reply('Pong...');
    }
});

client.login(process.env.TOKEN)